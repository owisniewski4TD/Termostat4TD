public class Termostat
{
    public double aktualnaTemperatura = 24.5;
    public double ustawionaTemperatura = 29.0;
    public boolean ogrzewanieWlaczone = false;
    public boolean chlodzenieWlaczone = false;
    public void wlaczOgrzewanie()
    {
        ogrzewanieWlaczone = true;
        chlodzenieWlaczone = false;
        System.out.println("Ogrzewanie włączone.");
    }
    public void wlaczChlodzenie()
    {
        chlodzenieWlaczone = true;
        ogrzewanieWlaczone = false;
        System.out.println("Chłodzenie włączone.");
    }
    public void wylaczOgrzewanie()
    {
        ogrzewanieWlaczone = false;
        System.out.println("Ogrzewanie wyłączone.");
    }
    public void wylaczChlodzenie()
    {
        chlodzenieWlaczone = false;
        System.out.println("Chłodzenie wyłączone.");
    }
    public void sprawdzTemperature()
    {
        System.out.println("Aktualna temperatura: " + aktualnaTemperatura + " stopni Celsjusza");
        System.out.println("Ustawiona temperatura: " + ustawionaTemperatura + " stopni Celsjusza");
        if (aktualnaTemperatura < ustawionaTemperatura && !ogrzewanieWlaczone)
        {
            wlaczOgrzewanie();
        } else if (aktualnaTemperatura > ustawionaTemperatura && !chlodzenieWlaczone)
        {
            wlaczChlodzenie();
        } else if (aktualnaTemperatura == ustawionaTemperatura)
        {
            wylaczOgrzewanie();
            wylaczChlodzenie();
            System.out.println("Temperatura osiągnięta.");
        }
    }
    public void symulujZmianeTemperatury()
    {
        if (ogrzewanieWlaczone)
        {
            aktualnaTemperatura += 0.5;
        } else if (chlodzenieWlaczone)
        {
            aktualnaTemperatura -= 0.5;
        }
    }
    public static void main(String[] args)
    {
        Termostat termostat = new Termostat();
        for (int i = 0; i < 10; i++)
        {
            termostat.symulujZmianeTemperatury();
            termostat.sprawdzTemperature();
            System.out.println("");
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {

            }
        }
    }
}