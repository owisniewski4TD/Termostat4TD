import java.util.ArrayList;
import java.util.List;

public class Student {
    private String imie;
    private String nazwisko;
    private double ocena;
    private char plec;
    private String kierunek;
    public Student(String imie, String nazwisko, double ocena, char plec, String kierunek)
    {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.ocena = ocena;
        this.plec = plec;
        this.kierunek = kierunek;
    }
    public void WyswietlInformacje()
    {
        System.out.println("Imię: " + imie);
        System.out.println("Nazwisko: " + nazwisko);
        System.out.println("Ocena: " + ocena);
        System.out.println("Płeć: " + plec);
        System.out.println("Kierunek: " + kierunek);
    }
    public void ZmienKierunek(String nowyKierunek)
    {
        this.kierunek = nowyKierunek;
        WyswietlInformacje();
    }
    public void ZmienOcene(double nowaOcena)
    {
        this.ocena = nowaOcena;
        WyswietlInformacje();
    }
    public double ObliczSredniaOcen()
    {
        return ocena;
    }
    public void ZmienImie(String noweImie)
    {
        this.imie = noweImie;
    }
    public void ZmienNazwisko(String noweNazwisko)
    {
        this.nazwisko = noweNazwisko;
    }
    public boolean SprawdzZaliczenie()
    {
        return ocena >= 3.0;
    }
    public void UstawPlec(char nowaPlec)
    {
        this.plec = nowaPlec;
    }
    public static double WyswietlSredniaOcenaKierunku(String kierunek, List<Student> listaStudentow)
    {
        double sumaOcen = 0;
        int liczbaStudentow = 0;
        for (Student student : listaStudentow)
        {
            if (student.kierunek.equals(kierunek))
            {
                sumaOcen += student.ocena;
                liczbaStudentow++;
            }
        }
        if (liczbaStudentow == 0)
        {
            System.out.println("Brak studentów na kierunku: " + kierunek);
            return 0;
        }
        return sumaOcen / liczbaStudentow;
    }

    public static void main(String[] args)
    {
        Student student1 = new Student("Jan", "Górnik", 4.5, 'M', "Informatyka");
        Student student2 = new Student("Anna", "Wiśniewska", 3.0, 'K', "Medycyna");
        Student student3 = new Student("Zygmunt", "Nowacki", 5.0, 'M', "Prawo");
        Student student4 = new Student("Eustachy", "Kowalski", 2.5, 'M', "Informatyka");
        Student student5 = new Student("Natalia", "Lewandowska", 1.5, 'K', "Psychologia");

        student1.WyswietlInformacje();
        student2.WyswietlInformacje();
        student3.WyswietlInformacje();
        student4.WyswietlInformacje();
        student5.WyswietlInformacje();

        student1.ZmienKierunek("Elektronika");
        student2.ZmienOcene(4.0);

        student1.ZmienImie("Marek");
        student2.ZmienNazwisko("Kowal");

        System.out.println("Czy student 1 zaliczył? " + student1.SprawdzZaliczenie());
        System.out.println("Czy student 2 zaliczył? " + student2.SprawdzZaliczenie());
        System.out.println("Czy student 3 zaliczył? " + student3.SprawdzZaliczenie());
        System.out.println("Czy student 4 zaliczył? " + student4.SprawdzZaliczenie());
        System.out.println("Czy student 5 zaliczył? " + student5.SprawdzZaliczenie());

        List<Student> listaStudentow = new ArrayList<>();
        listaStudentow.add(student1);
        listaStudentow.add(student2);
        listaStudentow.add(student3);
        listaStudentow.add(student4);
        listaStudentow.add(student5);

        double sredniaOcenaInformatyka = Student.WyswietlSredniaOcenaKierunku("Informatyka", listaStudentow);
        System.out.println("Średnia ocena na kierunku Informatyka: " + sredniaOcenaInformatyka);
    }
}
